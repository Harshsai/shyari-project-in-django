from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Shayari(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    shayari_title = models.CharField(max_length=100)
    shayari = models.TextField(max_length=500)


class Jokes(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    jokes_title = models.CharField(max_length=100)
    jokes = models.TextField(max_length=500)    


   
