from django.contrib import admin
from .models import Shayari , Jokes

# Register your models here.

@admin.register(Shayari)
class Shayari(admin.ModelAdmin):
    list_display = ['id', 'shayari_title', 'shayari', 'user_id' ]

@admin.register(Jokes)
class Jokes(admin.ModelAdmin):
    list_display = ['id', 'jokes_title', 'jokes', 'user_id']








