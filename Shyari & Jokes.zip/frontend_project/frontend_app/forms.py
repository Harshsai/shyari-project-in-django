from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm 
from .models import Shayari , Jokes

class SignUpForm(UserCreationForm):
    password2 = forms.CharField(label='Confirm Password (again)', widget=forms.PasswordInput())
    class Meta:
        model = User
        fields = ['username', 'email']
        labels = {  'username' : 'Username', 'email' : 'Email (Optional) ', }

        # labels = { 'first_name': 'First Name (Optional) ' , 'last_name': 'Last Name (Optional) ', 'username' : 'Username', 'email' : 'Email (Optional) ', }
         
class ShayariFom(forms.ModelForm):
    class Meta:
        model =  Shayari
        fields = ['shayari_title', 'shayari']        

class JokesFom(forms.ModelForm):
    class Meta:
        model =  Jokes
        fields =  ['jokes_title', 'jokes']