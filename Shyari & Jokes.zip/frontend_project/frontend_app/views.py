from django.shortcuts import render , redirect, HttpResponse
from django.contrib import messages
from .forms import SignUpForm , ShayariFom , JokesFom
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import Shayari , Jokes

# Create your views here.
def index(request):
    return render (request, 'index.html')

def signup(request):
    if request.method == "POST":
        fm = SignUpForm(request.POST)
        if fm.is_valid():
            fm.save()
            messages.success(request, 'Account Created Successfully !! ')
            return redirect ('profile')
            
    else:
        fm = SignUpForm()    
    return render (request, 'signup.html', {'form' : fm})

def login_v(request):
  if not request.user.is_authenticated:
    if request.method == "POST":
        fm =  AuthenticationForm(request=request, data=request.POST)
        if fm.is_valid():
            uname = fm.cleaned_data['username']
            upass = fm.cleaned_data['password'] 
            user = authenticate(username=uname, password=upass) 
            if user is not None:
                login(request, user)
                messages.success(request, 'Login Successfully !! ')
                return redirect ('profile')
    else:  
        fm = AuthenticationForm()
  else:
    return redirect('profile')      
  return render (request, 'login.html', {'form': fm})

@login_required(login_url='login')
def profile(request):
    all_shayari = Shayari.objects.all()
    all_jokes = Jokes.objects.all()
    return render (request, 'profile.html', {'all_sha': all_shayari, 'all_jok': all_jokes})


@login_required(login_url='login')
def shayari(request):
    if request.method == "POST":
        Shayari = ShayariFom(request.POST)
        Shayari.is_valid()
        instance = Shayari.save(commit=False)
        instance.user = request.user
        instance.save()
        return redirect('profile')
    else:
      Shayari = ShayariFom() 
    return render (request, 'shayari.html', { 'sha': ShayariFom})     


@login_required(login_url='login')
def jokes(request):
    if request.method == "POST":
        jok = JokesFom(request.POST)
        jok.is_valid()
        instance = jok.save(commit=False)
        instance.user = request.user
        instance.save()
        return redirect('profile')
    else:
      jok = JokesFom() 
    return render (request, 'jokes.html', {'jok': JokesFom,}) 

@login_required(login_url='login')
def shayari_read(request):
    shayari_r = Shayari.objects.filter(user__id=request.user.id)
    return render (request, 'shayari_read.html', {'sha': shayari_r })


@login_required(login_url='login')
def jokes_read(request):
    jokes_r = Jokes.objects.filter(user__id=request.user.id)
    return render (request, 'jokes_read.html', {'joke' : jokes_r})        

def logout_user(request):
    logout(request)
    return redirect ('login')









                
