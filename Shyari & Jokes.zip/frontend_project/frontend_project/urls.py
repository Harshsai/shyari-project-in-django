from django.contrib import admin
from django.urls import path
from frontend_app import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.index, name='index'),
    path('signup/',views.signup, name='signup'),
    path('login/',views.login_v, name='login'),
    path('profile/',views.profile, name='profile'),
    path('jokes/',views.jokes, name='jokes'),
    path('shayari/',views.shayari, name='shayari'),
    path('shayari_read/',views.shayari_read, name='shayari_read'),
    path('jokes_read/',views.jokes_read, name='jokes_read'),
    path('logout/',views.logout_user, name='logout'),
]
